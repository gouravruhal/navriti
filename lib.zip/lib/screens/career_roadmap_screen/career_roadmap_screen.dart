import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CareerRoadmapScreen extends StatelessWidget {
  final Map<String, dynamic> reportData;
  const CareerRoadmapScreen({Key? key, required this.reportData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final stream = reportData["stream"] ?? "Unknown";
    final justification = reportData["justification"] ?? "";
    final percent = reportData["interestPercent"] ?? 0;
    final comparison = reportData["comparison"] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text("Career Roadmap",
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.blue.shade900,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Recommended Stream: $stream",
                style: GoogleFonts.poppins(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text("Why: $justification", style: GoogleFonts.poppins(fontSize: 16)),
            const SizedBox(height: 8),
            Text("Interest Level: $percent%", style: GoogleFonts.poppins(fontSize: 16)),
            const SizedBox(height: 16),
            Text("Comparison with other streams:", style: GoogleFonts.poppins(fontSize: 18)),
            ...comparison.map<Widget>((c) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text("${c['stream']}: ${c['score']}%",
                  style: GoogleFonts.poppins(fontSize: 16)),
            )),
            const Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // TODO: Navigate to deep research or external page
                },
                child: const Text("Deep Research"),
              ),
            )
          ],
        ),
      ),
    );
  }
}
