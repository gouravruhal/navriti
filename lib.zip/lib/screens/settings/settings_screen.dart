import 'package:flutter/material.dart';
import '../../widgets/shared_widgets.dart';
import '../home/PrimaryBottomNav.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      bottomNavigationBar: PrimaryBottomNav(currentIndex: 4),
      body: ListView(
        children: [
          SwitchListTile(value: true, onChanged: (v){}, title: Text('Offline mode')),
          ListTile(title: Text('Language'), subtitle: Text('Hindi / English (Hinglish)'), onTap: (){}),
          ListTile(title: Text('Privacy & Data'), onTap: (){}),
          ListTile(title: Text('Help Center'), onTap: ()=> Navigator.pushNamed(context, '/help_center')),
        ],
      ),
    );
  }
}
