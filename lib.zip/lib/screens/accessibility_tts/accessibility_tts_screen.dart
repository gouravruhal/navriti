import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class AccessibilityTtsScreen extends StatefulWidget {
  @override
  _AccessibilityTtsScreenState createState() => _AccessibilityTtsScreenState();
}

class _AccessibilityTtsScreenState extends State<AccessibilityTtsScreen> {
  final FlutterTts _flutterTts = FlutterTts();
  bool _ttsEnabled = true;
  String _selectedVoice = "Female";
  String _selectedLanguage = "en-IN"; // default English (India)
  double _speechRate = 1.0;
  double _pitch = 1.0;
  bool _isPlaying = false;

  TextEditingController _previewController =
  TextEditingController(text: "Welcome to Navriti! This is your AI career guide.");

  @override
  void initState() {
    super.initState();
    _setupTts();
  }

  Future<void> _setupTts() async {
    await _flutterTts.setLanguage(_selectedLanguage);
    await _flutterTts.setSpeechRate(_speechRate);
    await _flutterTts.setPitch(_pitch);

    // Callbacks
    _flutterTts.setStartHandler(() {
      setState(() => _isPlaying = true);
    });
    _flutterTts.setCompletionHandler(() {
      setState(() => _isPlaying = false);
    });
    _flutterTts.setErrorHandler((err) {
      setState(() => _isPlaying = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("TTS Error: $err")),
      );
    });
  }

  Future<void> _speak() async {
    if (_ttsEnabled && _previewController.text.isNotEmpty) {
      await _flutterTts.setLanguage(_selectedLanguage);
      await _flutterTts.setSpeechRate(_speechRate);
      await _flutterTts.setPitch(_pitch);
      await _flutterTts.speak(_previewController.text);
    }
  }

  Future<void> _stop() async {
    await _flutterTts.stop();
    setState(() => _isPlaying = false);
  }

  @override
  void dispose() {
    _flutterTts.stop();
    _previewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Text-to-Speech"),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            _buildHeader(),
            _buildToggleCard(),
            _buildLanguageCard(),
            _buildSliders(),
            _buildPreviewCard(),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("TTS settings saved ✅")),
                );
              },
              icon: Icon(Icons.save),
              label: Text("Save Settings"),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                backgroundColor: Color(0xFF2563EB),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Hear your content",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text(
          "Enable text-to-speech so the app can read aloud quizzes, guides, and reports.",
          style: TextStyle(color: Colors.grey[700]),
        ),
        SizedBox(height: 12),
      ],
    );
  }

  Widget _buildToggleCard() {
    return SwitchListTile(
      activeColor: Color(0xFFF97316),
      secondary: Icon(Icons.volume_up, color: Color(0xFF2563EB)),
      title: Text("Enable TTS"),
      subtitle: Text("Turn text-to-speech on or off."),
      value: _ttsEnabled,
      onChanged: (val) {
        setState(() => _ttsEnabled = val);
        if (!val) _stop();
      },
    );
  }

  Widget _buildLanguageCard() {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: "Language",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      value: _selectedLanguage,
      items: {
        "English (India)": "en-IN",
        "Hindi": "hi-IN",
        "Urdu": "ur-IN",
        "Dogri": "doi-IN",
      }.entries.map((entry) {
        return DropdownMenuItem(value: entry.value, child: Text(entry.key));
      }).toList(),
      onChanged: (val) {
        setState(() => _selectedLanguage = val!);
        _setupTts();
      },
    );
  }

  Widget _buildSliders() {
    return Column(
      children: [
        ListTile(
          title: Text("Speech Speed"),
          subtitle: Slider(
            value: _speechRate,
            min: 0.5,
            max: 2.0,
            divisions: 6,
            label: _speechRate.toStringAsFixed(1),
            activeColor: Color(0xFF2563EB),
            onChanged: (val) {
              setState(() => _speechRate = val);
              _flutterTts.setSpeechRate(val);
            },
          ),
        ),
        ListTile(
          title: Text("Pitch"),
          subtitle: Slider(
            value: _pitch,
            min: 0.5,
            max: 2.0,
            divisions: 6,
            label: _pitch.toStringAsFixed(1),
            activeColor: Color(0xFF2563EB),
            onChanged: (val) {
              setState(() => _pitch = val);
              _flutterTts.setPitch(val);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPreviewCard() {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _previewController,
              decoration: InputDecoration(
                labelText: "Preview Text",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              maxLines: 2,
            ),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _isPlaying ? null : _speak,
                  icon: Icon(Icons.play_arrow),
                  label: Text("Play"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2563EB),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: _isPlaying ? _stop : null,
                  icon: Icon(Icons.stop),
                  label: Text("Stop"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
