import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ApplicationChecklistsScreen extends StatelessWidget {
  final List<Map<String, dynamic>> checklists = [
    {
      "title": "College Applications",
      "tasks": [
        {"task": "Fill personal information", "done": true},
        {"task": "Upload transcript", "done": false},
        {"task": "Write personal essay", "done": false},
      ]
    },
    {
      "title": "Scholarship Applications",
      "tasks": [
        {"task": "Research scholarships", "done": true},
        {"task": "Prepare documents", "done": false},
        {"task": "Submit applications", "done": false},
      ]
    },
    {
      "title": "Entrance Exams",
      "tasks": [
        {"task": "Register for exam", "done": true},
        {"task": "Prepare study material", "done": true},
        {"task": "Take mock tests", "done": false},
      ]
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Application Checklists", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: checklists.map((checklist) {
            return Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      checklist["title"],
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ...checklist["tasks"].map<Widget>((task) {
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(
                          task["done"] ? Icons.check_circle : Icons.circle_outlined,
                          color: task["done"] ? Colors.green : Colors.grey,
                        ),
                        title: Text(
                          task["task"],
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            decoration: task["done"] ? TextDecoration.lineThrough : null,
                            color: task["done"] ? Colors.grey : Colors.black,
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
