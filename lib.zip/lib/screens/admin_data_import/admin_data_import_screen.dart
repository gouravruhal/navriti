import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class AdminDataImportScreen extends StatefulWidget {
  @override
  _AdminDataImportScreenState createState() => _AdminDataImportScreenState();
}

class _AdminDataImportScreenState extends State<AdminDataImportScreen> {
  bool isImporting = false;
  double progress = 0.0;

  Future<void> _startImport() async {
    setState(() {
      isImporting = true;
      progress = 0.0;
    });

    // Mock import simulation
    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 400));
      setState(() {
        progress = i / 10;
      });
    }

    setState(() {
      isImporting = false;
    });

    _showSuccessDialog();
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            SizedBox(width: 8),
            Text("Import Complete"),
          ],
        ),
        content: Text(
          "Dataset has been successfully imported 🎉",
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text("OK", style: TextStyle(color: Colors.blue)),
          )
        ],
      ),
    );
  }

  Widget _buildImportOption(String title, IconData icon, Color color) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3,
      child: InkWell(
        onTap: _startImport,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: color.withOpacity(0.1),
                child: Icon(icon, color: color),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Icon(Icons.upload_file, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgressBar() {
    return Column(
      children: [
        Lottie.asset("assets/lottie/uploading.json", height: 150),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 10,
            backgroundColor: Colors.grey.shade300,
            borderRadius: BorderRadius.circular(8),
            color: Colors.blueAccent,
          ),
        ),
        SizedBox(height: 12),
        Text(
          "${(progress * 100).toInt()}% importing...",
          style: GoogleFonts.poppins(
              fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black87),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Admin Data Import", style: GoogleFonts.poppins()),
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isImporting
            ? Center(child: _buildProgressBar())
            : Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Choose dataset to import",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 20),
            _buildImportOption("College Dataset (CSV/Excel)", Icons.school,
                Colors.blue),
            _buildImportOption("Scholarships Dataset (JSON)",
                Icons.monetization_on, Colors.green),
            _buildImportOption("Careers Dataset (CSV/Excel)",
                Icons.work_outline, Colors.orange),
            _buildImportOption("Mentors Dataset", Icons.people,
                Colors.purpleAccent),
          ],
        ),
      ),
    );
  }
}
