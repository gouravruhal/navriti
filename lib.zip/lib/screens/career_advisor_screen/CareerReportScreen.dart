import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:convert';
import 'careerexplorescreen.dart';


// This is the same report screen from the previous response.
// It is designed to work with the `CareerAdvisorScreen`.

class CareerReportScreen extends StatelessWidget {
  final String reportJson;

  const CareerReportScreen({Key? key, required this.reportJson}) : super(key: key);

  Map<String, dynamic> _parseReportData() {
    try {
      final jsonStartIndex = reportJson.indexOf('{');
      final jsonEndIndex = reportJson.lastIndexOf('}');
      if (jsonStartIndex != -1 && jsonEndIndex != -1) {
        final jsonString =
            reportJson.substring(jsonStartIndex, jsonEndIndex + 1);
        return json.decode(jsonString);
      }
      throw Exception("No JSON object found in the response.");
    } catch (e) {
      print("Error parsing JSON report: $e");
      // Fallback data in case of AI response error
      return {
        "recommended_stream": "Analysis Error",
        "justification":
            "Could not generate a valid report. Please try the session again.",
        "medical_score": 20,
        "non_medical_score": 20,
        "commerce_score": 20,
        "arts_score": 20,
        "iti_score": 20,
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    final reportData = _parseReportData();
    final stream = reportData["recommended_stream"] ?? "N/A";
    final justification =
        reportData["justification"] ?? "No details available.";

    final scores = {
      "Medical": (reportData["medical_score"] ?? 0).toDouble(),
      "Non-Medical": (reportData["non_medical_score"] ?? 0).toDouble(),
      "Commerce": (reportData["commerce_score"] ?? 0).toDouble(),
      "Arts": (reportData["arts_score"] ?? 0).toDouble(),
      "ITI": (reportData["iti_score"] ?? 0).toDouble(),
    };

    final List<PieChartSectionData> pieSections =
        scores.entries.map((entry) {
      final isRecommended = entry.key == stream;
      return PieChartSectionData(
        color: _getColorForStream(entry.key),
        value: entry.value,
        title: '${entry.value.toInt()}%',
        radius: isRecommended ? 110 : 100,
        titleStyle: GoogleFonts.poppins(
          fontSize: isRecommended ? 18 : 15,
          fontWeight: FontWeight.bold,
          color: Colors.white,
          shadows: [
            const Shadow(color: Colors.black26, blurRadius: 2)
          ],
        ),
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text("Your Personalized Report",
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        backgroundColor: const Color(0xFF1A237E),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Here's What We Recommend",
                style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
            const SizedBox(height: 24),
            SizedBox(
              height: 250,
              child: PieChart(
                PieChartData(
                  sections: pieSections,
                  centerSpaceRadius: 0,
                  sectionsSpace: 2,
                  pieTouchData: PieTouchData(
                    touchCallback: (FlTouchEvent event, pieTouchResponse) {
                      // Optional: Add interactivity
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Wrap(
              spacing: 20,
              runSpacing: 10,
              children: scores.keys
                  .map((key) => _buildLegend(key, _getColorForStream(key)))
                  .toList(),
            ),
            const SizedBox(height: 32),
            _buildInfoCard(
              title: "Recommended Stream: $stream",
              content: justification,
              icon: Icons.star_rounded,
              color: _getColorForStream(stream),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A237E),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CareerExplorerScreen(
                        reportData: reportData,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.explore_rounded),
                label: Text("Explore Career Paths",
                    style: GoogleFonts.poppins(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getColorForStream(String stream) {
    switch (stream) {
      case "Medical": return Colors.red.shade400;
      case "Non-Medical": return Colors.blue.shade500;
      case "Commerce": return Colors.green.shade500;
      case "Arts": return Colors.orange.shade500;
      case "ITI": return Colors.purple.shade400;
      default: return Colors.grey.shade500;
    }
  }

  Widget _buildLegend(String name, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 16, height: 16, color: color),
        const SizedBox(width: 8),
        Text(name, style: GoogleFonts.poppins(fontSize: 15)),
      ],
    );
  }

  Widget _buildInfoCard(
      {required String title,
      required String content,
      required IconData icon,
      required Color color}) {
    return Card(
      elevation: 4,
      shadowColor: Colors.grey.withOpacity(0.3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          gradient: LinearGradient(
            colors: [color.withOpacity(0.1), Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Text(
              content,
              style: GoogleFonts.poppins(
                  fontSize: 16, height: 1.5, color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }
}

