import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:navriti_scaffold_jk/services/gemini_ai_service.dart'; // Make sure the path is correct

// --- Updated Data Models to hold detailed info ---
class CareerOption {
  final String name;
  final String description;
  CareerOption.fromJson(Map<String, dynamic> json)
      : name = json['career'] ?? 'N/A',
        description = json['description'] ?? 'No description available.';
}

class CollegeInfo {
  final String name;
  final List<String> courses;
  final String fees;
  CollegeInfo.fromJson(Map<String, dynamic> json)
      : name = json['college_name'] ?? 'N/A',
        courses = List<String>.from(json['courses'] ?? []),
        fees = json['estimated_annual_fee'] ?? 'Not available';
}

class DetailedRoadmap {
  final String streamName;
  final List<CareerOption> topCareers;
  final List<String> allCareers;
  final List<CollegeInfo> jkColleges;
  final List<CollegeInfo> nationalColleges;

  DetailedRoadmap.fromJson(Map<String, dynamic> json)
      : streamName = json['stream_name'] ?? 'N/A',
        topCareers = (json['top_career_picks'] as List<dynamic>?)
            ?.map((e) => CareerOption.fromJson(e))
            .toList() ??
            [],
        allCareers = List<String>.from(json['all_possible_careers'] ?? []),
        jkColleges = (json['college_guide']?['jammu_kashmir_colleges'] as List<dynamic>?)
            ?.map((e) => CollegeInfo.fromJson(e))
            .toList() ??
            [],
        nationalColleges = (json['college_guide']?['top_national_colleges'] as List<dynamic>?)
            ?.map((e) => CollegeInfo.fromJson(e))
            .toList() ??
            [];
}

class CareerExplorerScreen extends StatefulWidget {
  final Map<String, dynamic> reportData;
  const CareerExplorerScreen({Key? key, required this.reportData}) : super(key: key);

  @override
  _CareerExplorerScreenState createState() => _CareerExplorerScreenState();
}

class _CareerExplorerScreenState extends State<CareerExplorerScreen> {
  final GeminiAiService _aiService = GeminiAiService();
  // We'll store fetched roadmaps in a map to avoid re-fetching
  final Map<String, DetailedRoadmap> _roadmapCache = {};
  bool _isLoading = true;
  String? _error;
  late List<String> _sortedStreamNames;

  @override
  void initState() {
    super.initState();
    _sortAndFetchTopRoadmap();
  }

  void _sortAndFetchTopRoadmap() {
    final scores = {
      "Medical": (widget.reportData["medical_score"] ?? 0).toDouble(),
      "Non-Medical": (widget.reportData["non_medical_score"] ?? 0).toDouble(),
      "Commerce": (widget.reportData["commerce_score"] ?? 0).toDouble(),
      "Arts": (widget.reportData["arts_score"] ?? 0).toDouble(),
      "ITI": (widget.reportData["iti_score"] ?? 0).toDouble(),
    };

    // --- FIX IS HERE ---
    // First, sort the entries based on score
    final sortedEntries = scores.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    // Then, map the sorted entries to get the list of stream names
    _sortedStreamNames = sortedEntries.map((e) => e.key).toList();
    
    // Fetch the roadmap for the top recommended stream first
    if (_sortedStreamNames.isNotEmpty) {
      _fetchRoadmapForStream(_sortedStreamNames.first);
    } else {
      setState(() {
        _isLoading = false;
        _error = "No report data found to generate roadmaps.";
      });
    }
  }

  Future<void> _fetchRoadmapForStream(String streamName) async {
    if (_roadmapCache.containsKey(streamName)) return; // Don't fetch if already in cache

    setState(() {
      _isLoading = true;
      _error = null;
    });

    final analysisPrompt = """
    Generate a highly detailed and practical career guide for a 10th-grade student in India interested in the '$streamName' stream. The student is from Jammu & Kashmir. Provide the response ONLY in a valid JSON format with these exact keys:
    {
      "stream_name": "$streamName",
      "top_career_picks": [{"career": "Top Career 1", "description": "Brief 2-line practical description."}],
      "all_possible_careers": ["Career A", "Career B", "Career C"],
      "college_guide": {
        "jammu_kashmir_colleges": [{"college_name": "NIT Srinagar", "courses": ["B.Tech in CSE"], "estimated_annual_fee": "₹1.5 Lakhs - ₹2 Lakhs"}],
        "top_national_colleges": [{"college_name": "IIT Bombay", "courses": ["B.Tech"], "estimated_annual_fee": "₹2 Lakhs - ₹2.5 Lakhs"}]
      }
    }
    """;

    try {
      final jsonResponse = await _aiService.sendMessage(analysisPrompt);
      final jsonStartIndex = jsonResponse.indexOf('{');
      final jsonEndIndex = jsonResponse.lastIndexOf('}');
      if (jsonStartIndex != -1 && jsonEndIndex != -1) {
        final jsonString = jsonResponse.substring(jsonStartIndex, jsonEndIndex + 1);
        final decodedJson = json.decode(jsonString);
        _roadmapCache[streamName] = DetailedRoadmap.fromJson(decodedJson);
      } else {
        throw Exception("No JSON object in AI response.");
      }
    } catch (e) {
      _error = "Failed to load details for $streamName. Please check your internet connection.";
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: _sortedStreamNames.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Deep Career Explorer", style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          backgroundColor: const Color(0xFF1A237E),
          bottom: TabBar(
            isScrollable: true,
            tabs: _sortedStreamNames.map((name) => Tab(text: name)).toList(),
            onTap: (index) {
              _fetchRoadmapForStream(_sortedStreamNames[index]);
            },
          ),
        ),
        body: TabBarView(
          children: _sortedStreamNames.map((name) {
            if (_isLoading && !_roadmapCache.containsKey(name)) {
              return const Center(child: CircularProgressIndicator());
            }
            if (_error != null && _roadmapCache[name] == null) {
              return Center(child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(_error!, textAlign: TextAlign.center, style: GoogleFonts.poppins(color: Colors.red)),
              ));
            }
            if (_roadmapCache.containsKey(name)) {
              return _buildRoadmapDetails(_roadmapCache[name]!);
            }
            // This case handles when tabs are switched quickly
            return const Center(child: CircularProgressIndicator());
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildRoadmapDetails(DetailedRoadmap roadmap) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionCard("Top Career Picks", children: roadmap.topCareers.map((c) => ListTile(title: Text(c.name, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)), subtitle: Text(c.description))).toList()),
        _buildSectionCard("All Possible Careers", children: [Padding(padding: const EdgeInsets.all(16), child: Wrap(spacing: 8, runSpacing: 8, children: roadmap.allCareers.map((c) => Chip(label: Text(c))).toList()))]),
        _buildSectionCard("College Guide: Jammu & Kashmir", children: roadmap.jkColleges.map((c) => _collegeTile(c)).toList()),
        _buildSectionCard("College Guide: Top National", children: roadmap.nationalColleges.map((c) => _collegeTile(c)).toList()),
      ],
    );
  }

  Widget _collegeTile(CollegeInfo college) {
    return ListTile(
      title: Text(college.name, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
      subtitle: Text(college.courses.join(', ')),
      trailing: Text(college.fees, style: GoogleFonts.poppins(color: Colors.green.shade700, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildSectionCard(String title, {required List<Widget> children}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w700, color: const Color(0xFF1A237E))),
            const Divider(height: 20),
            ...children,
          ],
        ),
      ),
    );
  }
}

