import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:async';

// Services and other screens
// IMPORTANT: Humne yahan 'ai_service.dart' ko 'gemini_ai_service.dart' se badal diya hai
import 'package:navriti_scaffold_jk/services/gemini_ai_service.dart';
import 'CareerReportScreen.dart';

class CareerAdvisorScreen extends StatefulWidget {
  const CareerAdvisorScreen({Key? key}) : super(key: key);

  @override
  _CareerAdvisorScreenState createState() => _CareerAdvisorScreenState();
}

class _CareerAdvisorScreenState extends State<CareerAdvisorScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _chat = [];
  // IMPORTANT: Yahan bhi AiServices ko GeminiAiService se badal diya hai
  final GeminiAiService _chatService = GeminiAiService();
  final ScrollController _scrollController = ScrollController();

  bool _isLoading = false;
  Timer? _timer;
  int _secondsRemaining = 90; // 5 minutes
  bool _sessionEnded = false;

  @override
  void initState() {
    super.initState();
    _startSession();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining <= 0) {
        _timer?.cancel();
        if (!_sessionEnded) {
          _generateReport();
        }
      } else {
        if (mounted) {
          setState(() {
            _secondsRemaining--;
          });
        }
      }
    });
  }

  void _startSession() async {
    setState(() {
      _isLoading = true;
    });
    // AI se session shuru karwayenge
    final initialMessage = await _chatService.sendMessage(
        "Start a new career counseling session for a 10th-grade student. Greet them in Hinglish and ask your first question.");
    _addAIMessage(initialMessage);
    setState(() {
      _isLoading = false;
    });
  }

  void _addAIMessage(String text) {
    if (mounted) {
      setState(() {
        _chat.add({"role": "ai", "text": text});
      });
      _scrollToBottom();
    }
  }

  void _addUserMessage(String text) {
    if (mounted) {
      setState(() {
        _chat.add({"role": "user", "text": text});
      });
      _scrollToBottom();
    }
  }

  void _handleUserResponse(String userMessage) async {
    if (userMessage.trim().isEmpty || _isLoading || _sessionEnded) return;

    _addUserMessage(userMessage);
    _controller.clear();
    setState(() {
      _isLoading = true;
    });

    // User ka jawab AI ko bhejkar agla sawal lenge
    final nextQuestion = await _chatService.sendMessage(userMessage);
    _addAIMessage(nextQuestion);

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _generateReport() async {
    if (_sessionEnded) return;
    setState(() {
      _sessionEnded = true;
      _isLoading = true;
    });

    _addAIMessage(
        "Thanks for your time! Apke jawabon ke aadhar par main ek report generate kar raha hoon...");

    final conversationHistory = _chat
        .map((msg) =>
            "${msg['role'] == 'user' ? 'Student' : 'Counselor'}: ${msg['text']}")
        .join('\n');

    final analysisPrompt = """
    Based on the following conversation, analyze the student's interests and personality.
    Conversation: $conversationHistory
    Provide a response ONLY in a valid JSON format with these exact keys:
    {
      "recommended_stream": "A single stream from 'Medical', 'Non-Medical', 'Commerce', 'Arts', 'ITI'",
      "justification": "A brief, 2-line explanation for the recommendation.",
      "medical_score": An integer percentage (0-100),
      "non_medical_score": An integer percentage (0-100),
      "commerce_score": An integer percentage (0-100),
      "arts_score": An integer percentage (0-100),
      "iti_score": An integer percentage (0-100)
    }
    """;

    final jsonResponse = await _chatService.sendMessage(analysisPrompt);

    if (mounted) {
      // Make sure you have a CareerReportScreen that accepts a 'reportJson' parameter
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => CareerReportScreen(reportJson: jsonResponse),
        ),
      );
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Navriti AI Career Guide",
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.blue.shade900,
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                "${(_secondsRemaining ~/ 60).toString().padLeft(2, '0')}:${(_secondsRemaining % 60).toString().padLeft(2, '0')}",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w500, fontSize: 16),
              ),
            ),
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _chat.length,
              itemBuilder: (context, index) {
                final msg = _chat[index];
                final isUser = msg["role"] == "user";
                return Align(
                  alignment:
                      isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color:
                          isUser ? Colors.blue.shade900 : Colors.blue.shade100,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      msg["text"] ?? "",
                      style: GoogleFonts.poppins(
                        color: isUser ? Colors.white : Colors.black87,
                        fontSize: 14,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          if (_isLoading)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Navriti is thinking...",
                  style: GoogleFonts.poppins(fontStyle: FontStyle.italic)),
            ),
          if (!_sessionEnded)
            Container(
              padding: const EdgeInsets.all(8),
              color: Colors.grey.shade100,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                          hintText: "Apna jawab type karein...",
                          border: InputBorder.none),
                      onSubmitted: (val) {
                        _handleUserResponse(val);
                      },
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.send, color: Colors.blue.shade900),
                    onPressed: () {
                      _handleUserResponse(_controller.text);
                    },
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

