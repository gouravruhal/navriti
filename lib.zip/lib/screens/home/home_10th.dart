import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../routes.dart';
import 'BaseScreen.dart';

class Home10thScreen extends StatelessWidget {
  final String userName;

  const Home10thScreen({Key? key, required this.userName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      currentIndex: 0,
      showBackButton: false,
      title: "Welcome, $userName 👋",
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- Hero Section ---
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.deepPurpleAccent, Colors.deepPurple],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black26,
                      blurRadius: 6,
                      offset: Offset(2, 4))
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Your One-Stop Career Advisor",
                      style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Text(
                    "Confused about which stream to choose after 10th?\n"
                        "Let AI guide your journey 🚀",
                    style: GoogleFonts.poppins(
                        color: Colors.white70, fontSize: 14),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () =>
                        Navigator.pushNamed(context, Routes.careerAdvisor),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.deepPurple,
                      padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                    ),
                    child: Text("Start Career Journey"),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // --- Nearby Colleges ---
            Text("Explore Nearby Colleges",
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            _featureCard(context, "Search Colleges", Routes.collegeSearch,
                icon: Icons.school),

            const SizedBox(height: 20),

            // --- Quick Resources ---
            Text("Quick Resources",
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                    child: _featureCard(context, "Take Quiz", Routes.quizIntro,
                        icon: Icons.quiz)),
                const SizedBox(width: 12),
                Expanded(
                    child: _featureCard(
                        context, "Skill Catalog", Routes.skillCatalog,
                        icon: Icons.star)),
              ],
            ),

            const SizedBox(height: 20),

            // --- USP Features ---
            Text("Boost Your Future",
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            _featureCard(context, "Scholarships", Routes.scholarshipList,
                icon: Icons.card_giftcard),
            _featureCard(context, "Internship Finder", Routes.internshipFinder,
                icon: Icons.work),
            _featureCard(context, "Timeline Tracker", Routes.timelineTracker,
                icon: Icons.timeline),
          ],
        ),
      ),
    );
  }

  Widget _featureCard(BuildContext context, String title, String route,
      {IconData? icon}) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Colors.deepPurple.withOpacity(0.7), Colors.deepPurple]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black12, blurRadius: 4, offset: Offset(2, 4))
          ],
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: Colors.white, size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Text(title,
                  style: GoogleFonts.poppins(
                      color: Colors.white, fontWeight: FontWeight.w600)),
            ),
            const Icon(Icons.arrow_forward_ios,
                color: Colors.white, size: 16),
          ],
        ),
      ),
    );
  }
}
