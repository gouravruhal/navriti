import 'package:flutter/material.dart';
import 'PrimaryBottomNav.dart';

class BaseScreen extends StatelessWidget {
  final Widget body;
  final int currentIndex;
  final String? title;
  final bool showBackButton;

  const BaseScreen({
    Key? key,
    required this.body,
    required this.currentIndex,
    this.title,
    this.showBackButton = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title ?? ''),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        automaticallyImplyLeading: showBackButton,
      ),
      body: body,
      bottomNavigationBar: PrimaryBottomNav(currentIndex: currentIndex),
    );
  }
}
