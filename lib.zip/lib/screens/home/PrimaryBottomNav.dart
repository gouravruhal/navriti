import 'package:flutter/material.dart';
import '../../routes.dart';

class PrimaryBottomNav extends StatelessWidget {
  final int currentIndex;

  const PrimaryBottomNav({Key? key, required this.currentIndex})
      : super(key: key);

  void _safeNavigate(BuildContext context, String route, {Map<String, dynamic>? arguments}) {
    if (ModalRoute.of(context)?.settings.name != route) {
      Navigator.pushReplacementNamed(context, route, arguments: arguments);
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      type: BottomNavigationBarType.fixed,
      onTap: (i) {
        switch (i) {
          case 0:
            _safeNavigate(context, Routes.mainBottomNav,
                arguments: {'userName': 'User', 'studentClass': '10th'});
            break;
          case 1:
            _safeNavigate(context, Routes.collegeSearch);
            break;
          case 2:
            _safeNavigate(context, Routes.quizIntro);
            break;
          case 3:
            _safeNavigate(context, Routes.mentorDirectory);
            break;
          case 4:
            _safeNavigate(context, Routes.profileLite,
                arguments: {'state': 'Gujarat'});
            break;
        }
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.school), label: "Colleges"),
        BottomNavigationBarItem(icon: Icon(Icons.quiz), label: "Quiz"),
        BottomNavigationBarItem(icon: Icon(Icons.people), label: "Mentors"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}
