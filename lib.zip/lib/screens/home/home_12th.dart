import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../routes.dart';
import 'BaseScreen.dart';

class Home12thScreen extends StatelessWidget {
  final String userName;
  final String stream; // Engineering / Commerce / Arts / Medical etc.

  const Home12thScreen({
    Key? key,
    required this.userName,
    required this.stream,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      currentIndex: 0,
      showBackButton: false,
      title: "Welcome, $userName (12th - $stream)",
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Career Path Section
            Text(
              "Career Path",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),

            if (stream == "Engineering") ...[
              _advisoryCard(
                context,
                "JEE / NEET Prep",
                "Track your preparation",
              ),
              _advisoryCard(
                context,
                "Top Engineering Colleges",
                "IITs / NITs / Private Universities",
              ),
              _advisoryCard(
                context,
                "Skills Roadmap",
                "AI / ML / Data Science / Software Development",
              ),
            ] else if (stream == "Commerce") ...[
              _advisoryCard(
                context,
                "CA / CS / CMA Prep",
                "Professional courses",
              ),
              _advisoryCard(
                context,
                "Top Commerce Colleges",
                "DU / Christ / Private Universities",
              ),
              _advisoryCard(
                context,
                "Career Options",
                "Banking / Finance / MBA / B.Com",
              ),
            ] else if (stream == "Arts") ...[
              _advisoryCard(
                context,
                "UPSC / Govt. Exams",
                "Career in civil services",
              ),
              _advisoryCard(
                context,
                "Humanities Colleges",
                "Delhi University, JNU, Private",
              ),
              _advisoryCard(
                context,
                "Creative Careers",
                "Design / Journalism / Psychology",
              ),
            ] else ...[
              _advisoryCard(
                context,
                "General Options",
                "Explore multiple paths",
              ),
            ],

            const SizedBox(height: 20),

            // Study Resources Section
            Text(
              "Study Resources",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),

            _resourceCard(context, "Scholarships", Routes.scholarshipList),
            _resourceCard(context, "Internships", Routes.internshipFinder),
            _resourceCard(context, "Timeline Tracker", Routes.timelineTracker),
          ],
        ),
      ),
    );
  }

  Widget _advisoryCard(
      BuildContext context,
      String title,
      String subtitle,
      ) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(2, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.poppins(
              fontSize: 12,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }

  Widget _resourceCard(
      BuildContext context,
      String title,
      String route,
      ) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.deepPurple.withOpacity(0.7),
              Colors.deepPurple,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          title,
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
