import 'package:flutter/material.dart';
import 'home_10th.dart';
import 'home_12th.dart';

class HomeScreen extends StatelessWidget {
  final String userName;
  final String studentClass; // "10th" or "12th"
  final String? stream; // only for 12th (Engineering/Commerce/Arts/Medical etc.)

  const HomeScreen({
    Key? key,
    this.userName = "User",
    required this.studentClass,
    this.stream,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (studentClass == "10th") {
      return Home10thScreen(userName: userName);
    } else if (studentClass == "12th") {
      return Home12thScreen(userName: userName, stream: stream ?? "General");
    } else {
      return Scaffold(
        body: Center(child: Text("Invalid student class")),
      );
    }
  }
}
