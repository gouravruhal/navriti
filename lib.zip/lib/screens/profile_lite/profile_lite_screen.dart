import 'package:flutter/material.dart';
import '../../routes.dart';

class ProfileLiteScreen extends StatefulWidget {
  final String state; // comes from state selector

  const ProfileLiteScreen({Key? key, required this.state}) : super(key: key);

  @override
  State<ProfileLiteScreen> createState() => _ProfileLiteScreenState();
}

class _ProfileLiteScreenState extends State<ProfileLiteScreen> {
  String? selectedClass; // "10th" or "12th"
  String? selectedStream; // only for 12th

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Profile Setup")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Select Class
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: "Select Class"),
              value: selectedClass,
              items: ["10th", "12th"]
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  selectedClass = val;
                  selectedStream = null; // reset stream
                });
              },
            ),

            const SizedBox(height: 16),

            // If 12th -> show stream dropdown
            if (selectedClass == "12th")
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: "Select Stream"),
                value: selectedStream,
                items: ["Engineering", "Commerce", "Arts", "Medical"]
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: (val) {
                  setState(() => selectedStream = val);
                },
              ),

            const Spacer(),

            ElevatedButton(
              onPressed: () {
                if (selectedClass == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Please select a class")));
                  return;
                }
                if (selectedClass == "12th" && selectedStream == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Please select a stream")));
                  return;
                }

                Navigator.pushReplacementNamed(
                  context,
                  Routes.home,
                  arguments: {
                    "userName": "Student",
                    "studentClass": selectedClass!,
                    "stream": selectedStream,
                  },
                );
              },
              child: const Text("Continue"),
            ),
          ],
        ),
      ),
    );
  }
}
