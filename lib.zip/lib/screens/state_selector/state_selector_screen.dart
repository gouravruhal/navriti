import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:navriti_scaffold_jk/routes.dart'; // Direct screen import hata kar routes.dart import kiya.

class StateSelectorScreen extends StatefulWidget {
  @override
  _StateSelectorScreenState createState() => _StateSelectorScreenState();
}

class _StateSelectorScreenState extends State<StateSelectorScreen> {
  final List<String> states = [
    "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh",
    "Delhi","Goa","Gujarat","Haryana","Himachal Pradesh",
    "Jammu & Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
    "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland",
    "Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu",
    "Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal"
  ];

  String query = "";

  @override
  Widget build(BuildContext context) {
    final filteredStates = states.where((s) => s.toLowerCase().contains(query.toLowerCase())).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text("Select Your State", style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search state...",
                prefixIcon: Icon(Icons.search, color: Colors.blueAccent),
                filled: true,
                fillColor: Colors.blue.shade50,
                contentPadding: EdgeInsets.symmetric(vertical: 12,horizontal: 16),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
              onChanged: (val) => setState(() => query = val),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(16),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemCount: filteredStates.length,
              itemBuilder: (context,index){
                final state = filteredStates[index];
                return GestureDetector(
                  onTap: (){
                    // Route constant ka istemal kiya gaya hai.
                    Navigator.pushNamed(
                      context,
                      Routes.profileLite,
                      arguments: {'state': state},
                    );
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 400),
                    curve: Curves.easeInOut,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.blueAccent, Colors.lightBlueAccent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: Colors.blueAccent.withOpacity(0.3), blurRadius: 8, offset: Offset(2,4))],
                    ),
                    child: Center(
                      child: Text(
                        state,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
