import 'package:flutter/material.dart';
import '../../routes.dart';
import '../home/home_screen.dart';
import '../Placeholder/PlaceholderScreen.dart';

class MainBottomNavScreen extends StatefulWidget {
  final String userName;
  final String studentClass;
  final String? stream; // only for 12th

  const MainBottomNavScreen({
    Key? key,
    required this.userName,
    required this.studentClass,
    this.stream,
  }) : super(key: key);

  @override
  State<MainBottomNavScreen> createState() => _MainBottomNavScreenState();
}

class _MainBottomNavScreenState extends State<MainBottomNavScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    // Define pages based on student class/stream
    List<Widget> pages;
    List<BottomNavigationBarItem> navItems;

    if (widget.studentClass == "10th") {
      // ---------- 10th Student ----------
      pages = [
        HomeScreen(userName: widget.userName, studentClass: "10th"),
        const PlaceholderScreen(title: "Choose Stream"),
        const PlaceholderScreen(title: "Career Options"),
        const PlaceholderScreen(title: "Schools/Colleges"),
        const PlaceholderScreen(title: "Profile"),
      ];

      navItems = const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.school), label: "Streams"),
        BottomNavigationBarItem(icon: Icon(Icons.work), label: "Careers"),
        BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: "Colleges"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ];
    } else {
      // ---------- 12th Student ----------
      String stream = widget.stream ?? "General";

      pages = [
        HomeScreen(
            userName: widget.userName,
            studentClass: "12th",
            stream: stream),
        const PlaceholderScreen(title: "Colleges"),
        const PlaceholderScreen(title: "Scholarships"),
        const PlaceholderScreen(title: "Internships"),
        const PlaceholderScreen(title: "Profile"),
      ];

      navItems = const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.school), label: "Colleges"),
        BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: "Scholarships"),
        BottomNavigationBarItem(icon: Icon(Icons.work), label: "Internships"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ];
    }

    return Scaffold(
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
        items: navItems,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
      ),
    );
  }
}
