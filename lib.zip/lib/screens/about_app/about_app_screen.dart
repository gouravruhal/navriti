// lib/screens/about/about_app_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AboutAppScreen extends StatefulWidget {
  const AboutAppScreen({Key? key}) : super(key: key);

  @override
  _AboutAppScreenState createState() => _AboutAppScreenState();
}

class _AboutAppScreenState extends State<AboutAppScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _logoController;
  late final Animation<double> _logoAnim;

  @override
  void initState() {
    super.initState();
    _logoController =
    AnimationController(vsync: this, duration: Duration(seconds: 6))
      ..repeat();
    _logoAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _logoController, curve: Curves.linear));
  }

  @override
  void dispose() {
    _logoController.dispose();
    super.dispose();
  }

  void _showShareSheet() {
    showModalBottomSheet(
      context: context,
      builder: (c) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Wrap(
              children: [
                ListTile(
                  leading: Icon(Icons.share),
                  title: Text('Share App'),
                  onTap: () {
                    Navigator.pop(c);
                    // stub: integrate share package or platform share
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Share action (stub)')),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.copy),
                  title: Text('Copy invite link'),
                  onTap: () {
                    Navigator.pop(c);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Link copied (stub)')),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.email),
                  title: Text('Contact support'),
                  onTap: () {
                    Navigator.pop(c);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Open mail client (stub)')),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildGradientHeader(double height) {
    return ClipRRect(
      borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(32), bottomRight: Radius.circular(32)),
      child: Container(
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1F3A93), Color(0xFF4277D6), Color(0xFFF39C12)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [0.0, 0.55, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // rotating circular logo
            Positioned(
              right: 18,
              top: 18,
              child: RotationTransition(
                turns: _logoAnim,
                child: Opacity(
                  opacity: 0.08,
                  child: Icon(
                    Icons.star,
                    size: 160,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            // content
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // app icon circle
                    Hero(
                      tag: 'navriti_logo',
                      child: Container(
                        width: 84,
                        height: 84,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black26,
                                blurRadius: 8,
                                offset: Offset(0, 4))
                          ],
                          gradient: LinearGradient(
                            colors: [Colors.white, Colors.white70],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.school_outlined,
                            color: Color(0xFF1F3A93),
                            size: 44,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    // title & tagline
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Navriti',
                            style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Career guidance • Gov college connect • Local-first',
                            style: GoogleFonts.poppins(
                                color: Colors.white70, fontSize: 13),
                          ),
                          SizedBox(height: 12),
                          Row(
                            children: [
                              _smallBadge('Govt-first', Icons.verified_user),
                              SizedBox(width: 8),
                              _smallBadge('Offline-friendly', Icons.wifi_off),
                              SizedBox(width: 8),
                              _smallBadge('Hinglish', Icons.language),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _smallBadge(String text, IconData icon) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white24,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: Colors.white),
          SizedBox(width: 6),
          Text(text, style: GoogleFonts.poppins(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _missionCard() {
    // Animated progress (mission completion)
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 0.74),
      duration: Duration(milliseconds: 800),
      builder: (context, val, child) {
        return Card(
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 6,
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Our Mission', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text(
                  'Make govt colleges the first choice by building awareness, guidance and local mentorship.',
                  style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey[700]),
                ),
                SizedBox(height: 12),
                // progress bar
                Stack(
                  children: [
                    Container(
                      height: 12,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    Container(
                      height: 12,
                      width: MediaQuery.of(context).size.width * 0.6 * val,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFF4277D6), Color(0xFFF39C12)]),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Text('${(val * 100).toStringAsFixed(0)}% Complete',
                        style: GoogleFonts.poppins(fontSize: 12, color: Colors.black87)),
                    Spacer(),
                    Text('Est. reach: 120k+ students',
                        style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600])),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _featureCard(String title, String subtitle, IconData icon,
      {Color? startColor, Color? endColor}) {
    startColor ??= Colors.white;
    endColor ??= Colors.white;
    return Container(
      width: 160,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [startColor!, endColor!]),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: Colors.white),
            ),
            SizedBox(height: 12),
            Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            SizedBox(height: 6),
            Text(subtitle, style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700])),
          ]),
        ),
      ),
    );
  }

  Widget _teamCard(String name, String role, String desc, Color color) {
    return GestureDetector(
      onTap: () {
        showDialog(
            context: context,
            builder: (c) {
              return AlertDialog(
                title: Text(name),
                content: Text(desc),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c), child: Text('Close'))
                ],
              );
            });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 400),
        curve: Curves.easeOut,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(colors: [color.withOpacity(0.9), color]),
        ),
        padding: EdgeInsets.all(12),
        child: Row(children: [
          CircleAvatar(
            backgroundColor: Colors.white,
            child: Text(name[0], style: TextStyle(color: color, fontWeight: FontWeight.bold)),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text(role, style: GoogleFonts.poppins(color: Colors.white70, fontSize: 12)),
            ]),
          ),
          Icon(Icons.chevron_right, color: Colors.white),
        ]),
      ),
    );
  }

  Widget _legalAccordion() {
    return Column(
      children: [
        ExpansionTile(
          title: Text('Privacy & Data', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
              child: Text(
                'We store minimal personal data locally and sync securely to government-approved endpoints where necessary. Data is encrypted in transit.',
                style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey[700]),
              ),
            )
          ],
        ),
        ExpansionTile(
          title: Text('Terms & Conditions', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
              child: Text(
                'Navriti is a guidance platform. We do not guarantee admissions nor job placements. Use the app for information and counselling.',
                style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey[700]),
              ),
            )
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final headerHeight = 180.0;
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: IconThemeData(color: Colors.black87),
        automaticallyImplyLeading: true,
        title: Text('About Navriti', style: GoogleFonts.poppins(color: Colors.black87)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          _buildGradientHeader(headerHeight),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _missionCard(),
                    SizedBox(height: 12),
                    Text('Core Features', style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
                    SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _featureCard('Career Quiz', 'Smart aptitudes & stream fit', Icons.quiz, startColor: Color(0xFF6A82FB), endColor: Color(0xFFFC5C7D)),
                          SizedBox(width: 10),
                          _featureCard('Local Colleges', 'Nearby govt college finder', Icons.location_on, startColor: Color(0xFF3CA55C), endColor: Color(0xFFb5ac49)),
                          SizedBox(width: 10),
                          _featureCard('Mentorship', '1:1 local mentors', Icons.person_pin, startColor: Color(0xFF11998e), endColor: Color(0xFF38ef7d)),
                          SizedBox(width: 10),
                          _featureCard('Scholarships', 'Filtered & verified', Icons.card_giftcard, startColor: Color(0xFF614385), endColor: Color(0xFF516395)),
                        ],
                      ),
                    ),
                    SizedBox(height: 16),
                    Text('The Team', style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
                    SizedBox(height: 8),
                    Column(
                      children: [
                        _teamCard('Amit Sharma', 'Product Lead', 'Amit builds the product vision and partnerships with local colleges.', Color(0xFF1F3A93)),
                        SizedBox(height: 8),
                        _teamCard('Fatima Bano', 'Head Counselling', 'Fatima leads the career counselling programs and mentor training.', Color(0xFFF39C12)),
                        SizedBox(height: 8),
                        _teamCard('Rohit Singh', 'Tech Lead', 'Rohit oversees engineering and the offline-first tech stack.', Color(0xFF4277D6)),
                      ],
                    ),
                    SizedBox(height: 16),
                    Text('Transparency & Safety', style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
                    SizedBox(height: 8),
                    _legalAccordion(),
                    SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                              onPressed: _showShareSheet,
                              icon: Icon(Icons.share),
                              label: Text('Share App')),
                        ),
                        SizedBox(width: 12),
                        OutlinedButton(
                          onPressed: () {
                            // Open feedback form or play store (stub)
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Open feedback (stub)')));
                          },
                          child: Text('Feedback'),
                        )
                      ],
                    ),
                    SizedBox(height: 14),
                    Center(
                      child: Text('Version 0.1.0 • Build 1', style: GoogleFonts.poppins(color: Colors.grey[600])),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
