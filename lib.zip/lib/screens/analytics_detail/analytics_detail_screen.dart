import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:fl_chart/fl_chart.dart';

class AnalyticsDetailScreen extends StatelessWidget {
  final Map<String, dynamic> analyticsData = {
    "streamFit": {"PCM": 78, "Commerce": 55, "Humanities": 50},
    "quizzesTaken": 5,
    "achievements": ["Top 10% in Logical Quiz", "Completed Aptitude Test", "Unlocked Career Map Badge"],
    "timeline": [
      {"event": "Completed 10th Quiz", "date": "2025-09-01"},
      {"event": "PCM Stream Suggested", "date": "2025-09-02"},
      {"event": "Completed Career Map", "date": "2025-09-05"},
    ]
  };

  @override
  Widget build(BuildContext context) {
    final streamFitEntries = analyticsData["streamFit"].entries.toList();
    List<BarChartGroupData> barGroups = [];
    for (int i = 0; i < streamFitEntries.length; i++) {
      barGroups.add(
        BarChartGroupData(
          x: i,
          barRods: [
            BarChartRodData(
              toY: streamFitEntries[i].value.toDouble(),
              color: Colors.blueAccent,
              width: 22,
              borderRadius: BorderRadius.circular(4),
            )
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Analytics Detail", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Stream Fit Cards
            Text("Stream Fit Score", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Column(
              children: analyticsData["streamFit"].entries.map<Widget>((entry) {
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 2,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: LinearPercentIndicator(
                      lineHeight: 16,
                      percent: entry.value / 100,
                      center: Text("${entry.value}%", style: GoogleFonts.poppins(color: Colors.white)),
                      backgroundColor: Colors.grey.shade300,
                      progressColor: Colors.blueAccent,
                      barRadius: Radius.circular(8),
                      leading: Text(entry.key, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            // Quiz Stats
            Text("Quizzes Taken", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  children: [
                    Icon(Icons.quiz, size: 36, color: Colors.orange),
                    SizedBox(width: 16),
                    Text("${analyticsData["quizzesTaken"]} Quizzes Completed", style: GoogleFonts.poppins(fontSize: 16)),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),

            // Timeline
            Text("Progress Timeline", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Column(
              children: analyticsData["timeline"].map<Widget>((item) {
                return ListTile(
                  leading: Icon(Icons.circle, size: 12, color: Colors.blueAccent),
                  title: Text(item["event"], style: GoogleFonts.poppins(fontSize: 14)),
                  trailing: Text(item["date"], style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey)),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            // Achievements
            Text("Achievements", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: analyticsData["achievements"].map<Widget>((ach) {
                return Chip(
                  label: Text(ach, style: GoogleFonts.poppins(fontSize: 12)),
                  backgroundColor: Colors.lightBlue.shade50,
                  avatar: Icon(Icons.star, color: Colors.orange, size: 18),
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                );
              }).toList(),
            ),
            SizedBox(height: 24),

            // Stream Comparison Chart using fl_chart
            Text("Stream Comparison Chart", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Container(
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: 100,
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: true),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          if (value.toInt() < streamFitEntries.length) {
                            return Text(streamFitEntries[value.toInt()].key, style: GoogleFonts.poppins(fontSize: 12));
                          }
                          return Text('');
                        },
                      ),
                    ),
                  ),
                  barGroups: barGroups,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
