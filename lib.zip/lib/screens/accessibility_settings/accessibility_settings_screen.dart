import 'package:flutter/material.dart';

class AccessibilitySettingsScreen extends StatefulWidget {
  @override
  _AccessibilitySettingsScreenState createState() => _AccessibilitySettingsScreenState();
}

class _AccessibilitySettingsScreenState extends State<AccessibilitySettingsScreen> {
  double _fontSize = 16;
  bool _highContrast = false;
  bool _dyslexiaFont = false;
  bool _reduceAnimations = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Accessibility"),
        centerTitle: true,
        elevation: 0,
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Colors.grey.shade100],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          children: [
            _buildHeader(),
            SizedBox(height: 20),
            _buildFontSizeCard(),
            _buildToggleCard(
              title: "High Contrast Mode",
              description: "Improve visibility with stronger colors.",
              value: _highContrast,
              onChanged: (val) => setState(() => _highContrast = val),
              icon: Icons.contrast,
            ),
            _buildToggleCard(
              title: "Dyslexia-Friendly Font",
              description: "Use fonts designed for easier reading.",
              value: _dyslexiaFont,
              onChanged: (val) => setState(() => _dyslexiaFont = val),
              icon: Icons.font_download,
            ),
            _buildToggleCard(
              title: "Reduce Animations",
              description: "Minimize motion for sensitive users.",
              value: _reduceAnimations,
              onChanged: (val) => setState(() => _reduceAnimations = val),
              icon: Icons.motion_photos_off,
            ),
            SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Accessibility settings saved ✅")),
                );
              },
              icon: Icon(Icons.save),
              label: Text("Save Settings"),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                backgroundColor: Color(0xFF2563EB),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Personalize your experience",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF111827)),
        ),
        SizedBox(height: 6),
        Text(
          "Adjust text, colors, and animations to make the app easier to use.",
          style: TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
        ),
      ],
    );
  }

  Widget _buildFontSizeCard() {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.text_fields, color: Color(0xFF2563EB)),
                SizedBox(width: 10),
                Text(
                  "Font Size",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ],
            ),
            Slider(
              value: _fontSize,
              min: 12,
              max: 28,
              divisions: 8,
              activeColor: Color(0xFF2563EB),
              label: "${_fontSize.round()}",
              onChanged: (val) {
                setState(() {
                  _fontSize = val;
                });
              },
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Text("Preview: Aa", style: TextStyle(fontSize: _fontSize)),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildToggleCard({
    required String title,
    required String description,
    required bool value,
    required Function(bool) onChanged,
    required IconData icon,
  }) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SwitchListTile(
        activeColor: Color(0xFFF97316),
        secondary: Icon(icon, color: Color(0xFF2563EB)),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(description, style: TextStyle(color: Colors.grey[600])),
        value: value,
        onChanged: onChanged,
      ),
    );
  }
}
