import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:fl_chart/fl_chart.dart';

class BookingFlowScreen extends StatelessWidget {
  final Map<String, dynamic> userProgress = {
    "interviewsBooked": 3,
    "sessionsCompleted": 2,
    "badges": ["First Interview", "Resume Ready", "Mock Interview Star"],
    "timeline": [
      {"event": "Created Profile", "date": "2025-09-01"},
      {"event": "Booked First Session", "date": "2025-09-03"},
      {"event": "Completed Mock Interview", "date": "2025-09-05"},
    ]
  };

  final List<Map<String, dynamic>> availableSessions = [
    {"title": "Resume Review", "duration": "30 min", "price": 0},
    {"title": "Mock Interview - Technical", "duration": "45 min", "price": 5},
    {"title": "Mock Interview - HR", "duration": "30 min", "price": 3},
    {"title": "Career Advisory Session", "duration": "60 min", "price": 10},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking Flow", style: GoogleFonts.poppins()),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Progress Overview
            Text("Your Progress", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Card(
                    color: Colors.purple.shade50,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text("${userProgress["interviewsBooked"]}", style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                          Text("Interviews Booked", style: GoogleFonts.poppins(fontSize: 14)),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Card(
                    color: Colors.orange.shade50,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text("${userProgress["sessionsCompleted"]}", style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.orange)),
                          Text("Sessions Completed", style: GoogleFonts.poppins(fontSize: 14)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),

            // Timeline
            Text("Activity Timeline", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Column(
              children: userProgress["timeline"].map<Widget>((item) {
                return ListTile(
                  leading: Icon(Icons.circle, size: 12, color: Colors.deepPurple),
                  title: Text(item["event"], style: GoogleFonts.poppins(fontSize: 14)),
                  trailing: Text(item["date"], style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey)),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            // Badges
            Text("Achievements & Badges", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: userProgress["badges"].map<Widget>((badge) {
                return Chip(
                  label: Text(badge, style: GoogleFonts.poppins(fontSize: 12)),
                  backgroundColor: Colors.deepPurple.shade50,
                  avatar: Icon(Icons.star, color: Colors.deepPurple, size: 18),
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            // Booking Options
            Text("Available Sessions", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Column(
              children: availableSessions.map<Widget>((session) {
                bool isFree = session["price"] == 0;
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Icon(Icons.play_circle_fill, color: isFree ? Colors.green : Colors.deepPurple),
                    title: Text(session["title"], style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                    subtitle: Text("${session["duration"]} • ${isFree ? "Free" : "\$${session["price"]}"}", style: GoogleFonts.poppins(fontSize: 12)),
                    trailing: ElevatedButton(
                      onPressed: () {
                        // Implement booking logic here
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Booked ${session["title"]}!")),
                        );
                      },
                      child: Text(isFree ? "Book Free" : "Book Now"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isFree ? Colors.green : Colors.deepPurple,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            // Interactive Chart for Session Stats
            Text("Session Completion Chart", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Container(
              height: 200,
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.deepPurple.shade50,
                borderRadius: BorderRadius.circular(16),
              ),
              child: BarChart(
                BarChartData(
                  barGroups: [
                    BarChartGroupData(x: 0, barRods: [BarChartRodData(toY: userProgress["sessionsCompleted"].toDouble(), color: Colors.deepPurple)]),
                    BarChartGroupData(x: 1, barRods: [BarChartRodData(toY: 5, color: Colors.orange)]),
                  ],
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          switch (value.toInt()) {
                            case 0:
                              return Text("Completed", style: GoogleFonts.poppins(fontSize: 12));
                            case 1:
                              return Text("Total", style: GoogleFonts.poppins(fontSize: 12));
                            default:
                              return Text("");
                          }
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: true, reservedSize: 30),
                    ),
                  ),
                  gridData: FlGridData(show: true),
                ),
              ),
            ),
            SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
