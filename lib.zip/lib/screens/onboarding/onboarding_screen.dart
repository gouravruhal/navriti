import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../state_selector/state_selector_screen.dart';
import 'package:navriti_scaffold_jk/routes.dart'; // Direct screen import hata kar routes.dart import kiya.

class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  bool isLastPage = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            PageView(
              controller: _controller,
              onPageChanged: (index) {
                setState(() => isLastPage = (index == 2));
              },
              children: [
                buildPage(
                  color1: Colors.deepPurple.shade400,
                  color2: Colors.indigo.shade800,
                  icon: Icons.explore_rounded,
                  title: "Discover Careers",
                  subtitle: "Explore career paths tailored to your interests.",
                ),
                buildPage(
                  color1: Colors.orange.shade400,
                  color2: Colors.red.shade600,
                  icon: Icons.school_rounded,
                  title: "Learn & Grow",
                  subtitle: "Get quizzes, mock interviews & skill-building.",
                ),
                buildPage(
                  color1: Colors.green.shade400,
                  color2: Colors.teal.shade700,
                  icon: Icons.emoji_events_rounded,
                  title: "Achieve Success",
                  subtitle: "Track your progress & unlock achievements.",
                ),
              ],
            ),
            Container(
              alignment: Alignment(0, 0.8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SmoothPageIndicator(
                    controller: _controller,
                    count: 3,
                    effect: ExpandingDotsEffect(
                      activeDotColor: Colors.white,
                      dotColor: Colors.white54,
                      dotHeight: 10,
                      dotWidth: 10,
                      expansionFactor: 4,
                    ),
                  ),
                  SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      TextButton(
                        onPressed: () {
                          // Navigation ke liye ab named route ka istemal kiya gaya hai.
                          Navigator.pushReplacementNamed(
                              context, Routes.stateSelector);
                        },
                        child: Text(
                          "SKIP",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        onPressed: () {
                          if (isLastPage) {
                            // Navigation ke liye ab named route ka istemal kiya gaya hai.
                            Navigator.pushReplacementNamed(
                                context, Routes.stateSelector);
                          } else {
                            _controller.nextPage(
                              duration: Duration(milliseconds: 400),
                              curve: Curves.easeInOut,
                            );
                          }
                        },
                        child: Text(isLastPage ? "GET STARTED" : "NEXT"),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildPage({
    required Color color1,
    required Color color2,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color1, color2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(40.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 100),
              SizedBox(height: 40),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
