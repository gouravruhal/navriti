import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';

class ApplyChecklistScreen extends StatefulWidget {
  @override
  _ApplyChecklistScreenState createState() => _ApplyChecklistScreenState();
}

class _ApplyChecklistScreenState extends State<ApplyChecklistScreen> {
  final List<Map<String, dynamic>> checklists = [
    {
      "title": "College Applications",
      "tasks": [
        {"task": "Fill personal information", "done": false},
        {"task": "Upload transcript", "done": false},
        {"task": "Write personal essay", "done": false},
      ]
    },
    {
      "title": "Scholarship Applications",
      "tasks": [
        {"task": "Research scholarships", "done": false},
        {"task": "Prepare documents", "done": false},
        {"task": "Submit applications", "done": false},
      ]
    },
    {
      "title": "Entrance Exams",
      "tasks": [
        {"task": "Register for exam", "done": false},
        {"task": "Prepare study material", "done": false},
        {"task": "Take mock tests", "done": false},
      ]
    },
  ];

  double getProgress(List tasks) {
    if (tasks.isEmpty) return 0.0;
    int completed = tasks.where((t) => t["done"] == true).length;
    return completed / tasks.length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Application Checklists", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: checklists.map((checklist) {
            double progress = getProgress(checklist["tasks"]);
            return Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              margin: const EdgeInsets.symmetric(vertical: 12),
              child: ExpansionTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      checklist["title"],
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      "${(progress * 100).toStringAsFixed(0)}%",
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.blueAccent,
                      ),
                    ),
                  ],
                ),
                childrenPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  LinearPercentIndicator(
                    lineHeight: 14,
                    percent: progress,
                    backgroundColor: Colors.grey.shade300,
                    progressColor: Colors.blueAccent,
                    barRadius: Radius.circular(8),
                  ),
                  const SizedBox(height: 12),
                  ...checklist["tasks"].map<Widget>((task) {
                    return CheckboxListTile(
                      value: task["done"],
                      title: Text(
                        task["task"],
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          decoration: task["done"] ? TextDecoration.lineThrough : null,
                          color: task["done"] ? Colors.grey : Colors.black,
                        ),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                      activeColor: Colors.blueAccent,
                      onChanged: (val) {
                        setState(() {
                          task["done"] = val;
                        });
                      },
                    );
                  }).toList(),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
