import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:fl_chart/fl_chart.dart';

class BackupPathPlannerScreen extends StatelessWidget {
  final Map<String, dynamic> careerData = {
    "careerPaths": [
      {
        "name": "Software Engineer",
        "skills": {"Coding": 80, "Problem Solving": 70, "Communication": 60},
        "progress": 75
      },
      {
        "name": "Data Scientist",
        "skills": {"Python": 85, "Statistics": 70, "Machine Learning": 60},
        "progress": 60
      },
      {
        "name": "Digital Marketer",
        "skills": {"SEO": 70, "Analytics": 65, "Creativity": 80},
        "progress": 50
      },
    ]
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Backup Path Planner", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Text("Your Career Backup Paths",
                style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "Explore alternate career paths based on your current skills and progress. Track your growth and stay prepared for multiple options.",
              style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey[700]),
            ),
            SizedBox(height: 24),

            // Career Cards
            Column(
              children: careerData["careerPaths"].map<Widget>((career) {
                final skills = career["skills"] as Map<String, int>;
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 10),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(career["name"],
                            style: GoogleFonts.poppins(
                                fontSize: 18, fontWeight: FontWeight.w600)),
                        SizedBox(height: 12),

                        // Skill bars
                        Column(
                          children: skills.entries.map<Widget>((entry) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: LinearPercentIndicator(
                                lineHeight: 14,
                                percent: entry.value / 100,
                                center: Text("${entry.value}%",
                                    style: GoogleFonts.poppins(
                                        color: Colors.white, fontSize: 12)),
                                backgroundColor: Colors.grey.shade300,
                                progressColor: Colors.blueAccent,
                                barRadius: Radius.circular(8),
                                leading: Text(entry.key,
                                    style: GoogleFonts.poppins(
                                        fontSize: 12, fontWeight: FontWeight.w500)),
                              ),
                            );
                          }).toList(),
                        ),
                        SizedBox(height: 12),

                        // Overall progress
                        Text("Overall Progress",
                            style: GoogleFonts.poppins(
                                fontSize: 14, fontWeight: FontWeight.w600)),
                        SizedBox(height: 6),
                        LinearPercentIndicator(
                          lineHeight: 16,
                          percent: career["progress"] / 100,
                          center: Text("${career["progress"]}%",
                              style: GoogleFonts.poppins(
                                  color: Colors.white, fontWeight: FontWeight.w500)),
                          backgroundColor: Colors.grey.shade300,
                          progressColor: Colors.green,
                          barRadius: Radius.circular(8),
                        ),
                        SizedBox(height: 12),

                        // Bar chart for skills
                        Container(
                          height: 150,
                          child: BarChart(
                            BarChartData(
                              alignment: BarChartAlignment.spaceAround,
                              maxY: 100,
                              titlesData: FlTitlesData(
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(showTitles: true, interval: 20),
                                ),
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    getTitlesWidget: (value, meta) {
                                      final index = value.toInt();
                                      if (index < 0 || index >= skills.length) return Container();
                                      return Text(
                                        skills.keys.elementAt(index),
                                        style: GoogleFonts.poppins(fontSize: 12),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              borderData: FlBorderData(show: false),
                              barGroups: List.generate(skills.length, (i) {
                                final val = skills.values.elementAt(i);
                                return BarChartGroupData(
                                  x: i,
                                  barRods: [
                                    BarChartRodData(
                                        toY: val.toDouble(),
                                        color: Colors.blueAccent,
                                        width: 16)
                                  ],
                                );
                              }),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
