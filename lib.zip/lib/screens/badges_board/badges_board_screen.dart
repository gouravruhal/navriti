import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';

class BadgesBoardScreen extends StatelessWidget {
  final List<Map<String, dynamic>> badges = [
    {"name": "Quiz Master", "icon": Icons.quiz, "earned": true},
    {"name": "Top Performer", "icon": Icons.emoji_events, "earned": true},
    {"name": "Career Explorer", "icon": Icons.explore, "earned": false},
    {"name": "Consistency Star", "icon": Icons.star, "earned": true},
    {"name": "Skill Upgrader", "icon": Icons.school, "earned": false},
    {"name": "Community Helper", "icon": Icons.handshake, "earned": true},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Badges Board", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade50, Colors.purple.shade50],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Your Achievements",
                style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Collect badges by completing quizzes, career activities, and skill challenges.",
                style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey[800]),
              ),
              SizedBox(height: 20),

              // Earned badges progress
              Text(
                "Progress",
                style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 8),
              LinearPercentIndicator(
                lineHeight: 16,
                percent: badges.where((b) => b["earned"]).length / badges.length,
                center: Text(
                  "${(badges.where((b) => b["earned"]).length / badges.length * 100).toInt()}%",
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w600),
                ),
                backgroundColor: Colors.grey.shade300,
                progressColor: Colors.orangeAccent,
                barRadius: Radius.circular(8),
              ),
              SizedBox(height: 20),

              // Badges grid
              Expanded(
                child: GridView.builder(
                  itemCount: badges.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1,
                  ),
                  itemBuilder: (context, index) {
                    final badge = badges[index];
                    return AnimatedContainer(
                      duration: Duration(milliseconds: 500),
                      decoration: BoxDecoration(
                        color: badge["earned"] ? Colors.orange.shade100 : Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: badge["earned"] ? Colors.orange.shade200.withOpacity(0.5) : Colors.black12,
                            blurRadius: 6,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            badge["icon"],
                            size: 40,
                            color: badge["earned"] ? Colors.orange.shade800 : Colors.grey.shade400,
                          ),
                          SizedBox(height: 8),
                          Text(
                            badge["name"],
                            textAlign: TextAlign.center,
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: badge["earned"] ? Colors.black87 : Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
