import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:fl_chart/fl_chart.dart';

class AiExplainabilityScreen extends StatelessWidget {
  final List<Map<String, dynamic>> aiFeatures = [
    {
      "title": "Stream Fit Score",
      "description": "Shows how well each stream (PCM, Commerce, Humanities) fits your aptitude and interests.",
      "icon": Icons.show_chart,
      "percent": 78
    },
    {
      "title": "Risk Assessment",
      "description": "Visualizes risks if you choose or skip a stream, including potential failure or ROI.",
      "icon": Icons.warning_amber,
      "percent": 60
    },
    {
      "title": "Alternative Pathways",
      "description": "Shows backup career options if you change streams later.",
      "icon": Icons.swap_horiz,
      "percent": 90
    },
    {
      "title": "Local Context Analysis",
      "description": "Filters suggestions based on your state/district conditions, colleges, and opportunities.",
      "icon": Icons.location_on,
      "percent": 85
    },
    {
      "title": "Scholarship & Fee Insights",
      "description": "Displays nearby college fees, scholarships, and affordability for chosen paths.",
      "icon": Icons.money,
      "percent": 75
    },
    {
      "title": "Future Income & ROI",
      "description": "Predicts future earnings for different career options and calculates expected ROI.",
      "icon": Icons.trending_up,
      "percent": 70
    },
    {
      "title": "Gamified Progress",
      "description": "Earn badges and unlock achievements as you explore AI-guided career paths.",
      "icon": Icons.emoji_events,
      "percent": 80
    },
    {
      "title": "One-to-One Mentorship",
      "description": "AI suggests mentors from local schools/colleges for guidance.",
      "icon": Icons.person,
      "percent": 65
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AI Explainability", style: GoogleFonts.poppins()),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "AI Features & Insights",
              style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 12),

            // Feature Cards
            Column(
              children: aiFeatures.map<Widget>((feature) {
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  margin: EdgeInsets.symmetric(vertical: 8),
                  elevation: 3,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(feature["icon"], color: Colors.blueAccent),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(feature["title"],
                                  style: GoogleFonts.poppins(
                                      fontSize: 16, fontWeight: FontWeight.w600)),
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        Text(
                          feature["description"],
                          style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey[700]),
                        ),
                        SizedBox(height: 12),
                        LinearPercentIndicator(
                          lineHeight: 14,
                          percent: feature["percent"] / 100,
                          center: Text("${feature["percent"]}%", style: GoogleFonts.poppins(fontSize: 12, color: Colors.white)),
                          progressColor: Colors.blueAccent,
                          backgroundColor: Colors.grey.shade300,
                          barRadius: Radius.circular(8),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
