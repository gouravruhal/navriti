import 'package:flutter/material.dart';
import 'routes.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navriti Scaffold',
      debugShowCheckedModeBanner: false,
      // App ab splash screen se shuru hogi.
      initialRoute: Routes.splash,
      // Saare navigation ko handle karne ke liye sirf onGenerateRoute ka istemal hoga.
      onGenerateRoute: Routes.onGenerateRoute,
    );
  }
}
