import 'package:flutter/material.dart';
import '../../routes.dart';

class SharedBottomNav {
  static void onItemTapped(BuildContext context, int i) {
    switch (i) {
      case 0:
        Navigator.pushReplacementNamed(
          context,
          Routes.mainBottomNav,
          arguments: {'userName': 'User', 'studentClass': '10th'},
        );
        break;
      case 1:
        Navigator.pushReplacementNamed(context, Routes.collegeSearch);
        break;
      case 2:
        Navigator.pushReplacementNamed(context, Routes.quizIntro);
        break;
      case 3:
        Navigator.pushReplacementNamed(context, Routes.mentorDirectory);
        break;
      case 4:
        Navigator.pushReplacementNamed(
          context,
          Routes.profileLite,
          arguments: {'state': 'Gujarat'},
        );
        break;
    }
  }
}
