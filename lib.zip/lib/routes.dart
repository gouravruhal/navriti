import 'package:flutter/material.dart';
import 'package:navriti_scaffold_jk/screens/Placeholder/PlaceholderScreen.dart';
import 'package:navriti_scaffold_jk/screens/career_advisor_screen/career_advisor_screen.dart';
import 'package:navriti_scaffold_jk/screens/career_roadmap_screen/career_roadmap_screen.dart';
import 'package:navriti_scaffold_jk/screens/home/home_screen.dart';
import 'package:navriti_scaffold_jk/screens/main_bottom_nav/main_bottom_nav_screen.dart';
import 'package:navriti_scaffold_jk/screens/onboarding/onboarding_screen.dart';
import 'package:navriti_scaffold_jk/screens/profile_lite/profile_lite_screen.dart';
import 'package:navriti_scaffold_jk/screens/splash/splash_screen.dart';
import 'package:navriti_scaffold_jk/screens/state_selector/state_selector_screen.dart';

class Routes {
  static const splash = '/';
  static const onboarding = '/onboarding';
  static const stateSelector = '/state_selector';
  static const profileLite = '/profile_lite';
  static const home = '/home';
  static const mainBottomNav = '/main_bottom_nav';
  static const careerAdvisor = '/career_advisor';
  static const careerRoadmap = '/career_roadmap';

  static const quizIntro = '/quiz_intro';
  static const skillCatalog = '/skill_catalog';
  static const careerMap = '/career_map_overview';
  static const mentorDirectory = '/mentor_directory';
  static const collegeSearch = '/college_search';
  static const scholarshipList = '/scholarship_list';
  static const internshipFinder = '/internship_finder';
  static const timelineTracker = '/timeline_tracker';

  static final Set<String> allRoutes = {
    splash,
    onboarding,
    stateSelector,
    profileLite,
    home,
    mainBottomNav,
    careerAdvisor,
    careerRoadmap,
    quizIntro,
    skillCatalog,
    careerMap,
    mentorDirectory,
    collegeSearch,
    scholarshipList,
    internshipFinder,
    timelineTracker,
  };

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    final args = settings.arguments as Map<String, dynamic>?;

    MaterialPageRoute<dynamic> buildRoute(Widget screen) {
      return MaterialPageRoute<dynamic>(
        builder: (BuildContext context) => screen,
        settings: settings,
      );
    }

    switch (settings.name) {
      case splash:
        return buildRoute(SplashScreen());

      case onboarding:
        return buildRoute(OnboardingScreen());

      case stateSelector:
        return buildRoute(StateSelectorScreen());

      case profileLite:
        final state = args?['state'] ?? '';
        return buildRoute(ProfileLiteScreen(state: state));

      case careerAdvisor:
        return buildRoute(const CareerAdvisorScreen());

      case careerRoadmap:
        final reportData = args?['reportData'] ?? {};
        return buildRoute(CareerRoadmapScreen(reportData: reportData));

      case home:
        final userName = args?['userName'] ?? 'User';
        final studentClass = args?['studentClass'] ?? '10th';
        final stream = args?['stream'];
        return buildRoute(HomeScreen(
          userName: userName,
          studentClass: studentClass,
          stream: stream,
        ));

      case mainBottomNav:
        final userName = args?['userName'] ?? 'User';
        final studentClass = args?['studentClass'] ?? '10th';
        final stream = args?['stream'];
        return buildRoute(MainBottomNavScreen(
          userName: userName,
          studentClass: studentClass,
          stream: stream,
        ));

      case quizIntro:
        return buildRoute(const PlaceholderScreen(title: 'Quiz Intro'));

      case skillCatalog:
        return buildRoute(const PlaceholderScreen(title: 'Skill Catalog'));

      case careerMap:
        return buildRoute(const PlaceholderScreen(title: 'Career Map'));

      case mentorDirectory:
        return buildRoute(const PlaceholderScreen(title: 'Mentor Directory'));

      case collegeSearch:
        return buildRoute(const PlaceholderScreen(title: 'College Search'));

      case scholarshipList:
        return buildRoute(const PlaceholderScreen(title: 'Scholarship List'));

      case internshipFinder:
        return buildRoute(const PlaceholderScreen(title: 'Internship Finder'));

      case timelineTracker:
        return buildRoute(const PlaceholderScreen(title: 'Timeline Tracker'));

      default:
        return buildRoute(const PlaceholderScreen(title: 'No Route Found'));
    }
  }
}
