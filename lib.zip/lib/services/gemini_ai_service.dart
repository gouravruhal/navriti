import 'package:google_generative_ai/google_generative_ai.dart';

/// This service connects to the online Google Gemini AI.
class GeminiAiService {
  // Make sure your Google Cloud API key is pasted here correctly.
  static const String _apiKey = 'AIzaSyCGw-Jyxdr9LvyB46vLcukoPmlGTUrepFs';

  final GenerativeModel _model;
  late final ChatSession _chatSession;

  GeminiAiService()
      : _model = GenerativeModel(
          model: 'gemini-1.5-flash-latest',
          apiKey: _apiKey,
        ) {
    // --- FIXED ---
    // We are now using a backward-compatible method to set the AI's personality
    // by starting the chat with a user instruction and a model response.
    _chatSession = _model.startChat(history: [
      Content.text(
        "You are 'Navriti', a friendly career counselor for Indian students. "
        "Your goal is to provide helpful advice in simple Hinglish. "
        "IMPORTANT: Keep your responses very short, under 20 words. "
        "Ask only one clear question at a time."
      ),
      // We add a fake model response to make the AI adopt the persona.
      Content.model([TextPart("Okay, I understand my role. I am ready to help.")])
    ]);
  }

  /// Sends a message to the AI and gets a response.
  Future<String> sendMessage(String message) async {
    try {
      final response = await _chatSession.sendMessage(Content.text(message));
      final text = response.text;

      if (text == null) {
        return "Sorry, I couldn't generate a response. Try asking differently.";
      }
      return text;
    } catch (e) {
      print("***************************************************");
      print("A GEMINI API ERROR OCCURRED! The error is:");
      print(e);
      print("***************************************************");
      
      if (e.toString().contains('ApiKeyInvalid')) {
        return "Oops! The API Key is invalid. Please check it again.";
      }
      if (e.toString().contains('permission_denied') || e.toString().contains('PermissionDenied')) {
        return "Error: Permission Denied. Make sure the Gemini API is enabled in your Google Cloud project.";
      }
      
      return "An error occurred. Please check the debug console for details.";
    }
  }
}

