/// A lightweight, local service to analyze student's interests and suggest career streams.
/// This can be used as an offline fallback if the Gemini AI API is not available.
class AiServices {
  // Helper method to capitalize the first letter of a string.
  static String _capitalize(String s) {
    if (s.isEmpty) return "";
    return "${s[0].toUpperCase()}${s.substring(1)}";
  }

  /// Analyzes a map of user's interests/skills and generates a full career report map.
  ///
  /// The input [interestScores] should be a map where keys are interest areas
  /// (like 'problem_solving', 'creativity', etc.) and values are their scores (e.g., 1 to 10).
  ///
  /// Returns a map in the same format as expected by the CareerReportScreen.
  static Map<String, dynamic> generateReport(
      Map<String, int> interestScores) {
    // 1. Define weights for each stream based on different interests.
    // These weights determine how much an interest contributes to a stream's score.
    const Map<String, Map<String, int>> streamWeights = {
      'Medical': {
        'biology': 30,
        'helping_others': 25,
        'memory': 20,
        'chemistry': 15,
        'patience': 10,
      },
      'Non-Medical': {
        'maths': 30,
        'problem_solving': 25,
        'physics': 20,
        'logic': 15,
        'technology': 10,
      },
      'Commerce': {
        'business': 30,
        'maths': 20,
        'economics': 20,
        'management': 20,
        'communication': 10,
      },
      'Arts': {
        'creativity': 25,
        'communication': 20,
        'social_causes': 20,
        'history': 15,
        'writing': 20,
      },
      'ITI': {
        'hands_on_work': 40,
        'technology': 25,
        'problem_solving': 20,
        'practical_skills': 15,
      },
    };

    // 2. Calculate the raw score for each stream.
    Map<String, double> rawScores = {};
    streamWeights.forEach((stream, weights) {
      double totalScore = 0;
      weights.forEach((interest, weight) {
        // Add weighted score if the interest exists in user's scores.
        totalScore += (interestScores[interest] ?? 0) * weight;
      });
      rawScores[stream] = totalScore;
    });

    // 3. Normalize scores to a percentage (0-100).
    // Find the maximum possible score for normalization.
    double maxScore = 0;
    rawScores.values.forEach((score) {
      if (score > maxScore) {
        maxScore = score;
      }
    });

    // Avoid division by zero if no interests matched.
    if (maxScore == 0) maxScore = 1;

    final Map<String, int> finalScores = {
      "medical_score": ((rawScores['Medical']! / maxScore) * 100).round(),
      "non_medical_score":
          ((rawScores['Non-Medical']! / maxScore) * 100).round(),
      "commerce_score": ((rawScores['Commerce']! / maxScore) * 100).round(),
      "arts_score": ((rawScores['Arts']! / maxScore) * 100).round(),
      "iti_score": ((rawScores['ITI']! / maxScore) * 100).round(),
    };

    // 4. Find the recommended stream with the highest score.
    String recommendedStream = 'Arts'; // Default recommendation
    int highestScore = 0;

    finalScores.forEach((key, value) {
      if (value > highestScore) {
        highestScore = value;
        // Convert score key to stream name (e.g., "medical_score" -> "Medical")
        recommendedStream = _capitalize(key.split('_')[0]);
      }
    });

    // 5. Build the final report map.
    return {
      "recommended_stream": recommendedStream,
      "justification":
          "Based on our local analysis, your interests align well with the skills required for the $recommendedStream stream.",
      ...finalScores, // Spread the final scores into the map
    };
  }
}
