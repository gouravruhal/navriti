import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/college_model.dart';
class DummyDataService {
  static List<College> colleges = [];
  static List<Map<String,dynamic>> scholarships = [];
  static Future<void> init() async {
    final cJson = await rootBundle.loadString('assets/data/jk_colleges.json');
    final sJson = await rootBundle.loadString('assets/data/jk_scholarships.json');
    final List<dynamic> cList = json.decode(cJson);
    colleges = cList.map((e) => College.fromJson(e)).toList();
    scholarships = List<Map<String,dynamic>>.from(json.decode(sJson));
  }
}
