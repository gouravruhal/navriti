class College {
  final String id;
  final String name;
  final String district;
  final String city;
  final double latitude;
  final double longitude;
  final List<dynamic> courses;
  final List<String> facilities;
  final Map<String,dynamic> contact;
  final List<dynamic> scholarships;

  College({
    required this.id,
    required this.name,
    required this.district,
    required this.city,
    required this.latitude,
    required this.longitude,
    required this.courses,
    required this.facilities,
    required this.contact,
    required this.scholarships,
  });

  factory College.fromJson(Map<String,dynamic> json) {
    return College(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      district: json['district'] ?? '',
      city: json['city'] ?? '',
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      courses: List<dynamic>.from(json['courses'] ?? []),
      facilities: List<String>.from(json['facilities'] ?? []),
      contact: Map<String,dynamic>.from(json['contact'] ?? {}),
      scholarships: List<dynamic>.from(json['scholarships'] ?? []),
    );
  }
}
